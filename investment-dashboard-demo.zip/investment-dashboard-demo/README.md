# Investor Dashboard Demo

A responsive, front-end-only dashboard inspired by the supplied screenshots.

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` and this README.
3. In repository Settings, open Pages.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`, then save.

## Important
This is a visual demo only. Balances, products, and orders are illustrative and are not real financial products. It does not process payments, collect bank details, promise returns, or provide investment services. Do not use it to solicit deposits or represent simulated values as real money.

A production financial service needs qualified legal/compliance review, secure authentication, audited server-side transaction records, privacy/security controls, and properly licensed payment/financial partners.
